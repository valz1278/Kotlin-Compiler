/* Hello World Example */

class HelloWorld {
  fun main () {
    // Print text to the console
    print ("Hello World")
  }
}