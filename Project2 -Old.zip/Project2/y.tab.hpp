/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_Y_TAB_HPP_INCLUDED
# define YY_YY_Y_TAB_HPP_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    LE = 258,                      /* LE  */
    GE = 259,                      /* GE  */
    EQ = 260,                      /* EQ  */
    NE = 261,                      /* NE  */
    ADD = 262,                     /* ADD  */
    SUB = 263,                     /* SUB  */
    MUL = 264,                     /* MUL  */
    DIV = 265,                     /* DIV  */
    BOOL = 266,                    /* BOOL  */
    BREAK = 267,                   /* BREAK  */
    CHAR = 268,                    /* CHAR  */
    CASE = 269,                    /* CASE  */
    CLASS = 270,                   /* CLASS  */
    CONTINUE = 271,                /* CONTINUE  */
    DECLARE = 272,                 /* DECLARE  */
    DO = 273,                      /* DO  */
    ELSE = 274,                    /* ELSE  */
    EXIT = 275,                    /* EXIT  */
    FLOAT = 276,                   /* FLOAT  */
    FOR = 277,                     /* FOR  */
    FUN = 278,                     /* FUN  */
    IF = 279,                      /* IF  */
    IN = 280,                      /* IN  */
    INT = 281,                     /* INT  */
    LOOP = 282,                    /* LOOP  */
    PRINT = 283,                   /* PRINT  */
    PRINTLN = 284,                 /* PRINTLN  */
    RANGE = 285,                   /* RANGE  */
    RETURN = 286,                  /* RETURN  */
    STRING = 287,                  /* STRING  */
    VAL = 288,                     /* VAL  */
    VAR = 289,                     /* VAR  */
    WHILE = 290,                   /* WHILE  */
    BOOL_CONST = 291,              /* BOOL_CONST  */
    REAL_CONST = 292,              /* REAL_CONST  */
    STR_CONST = 293,               /* STR_CONST  */
    ID = 294,                      /* ID  */
    INT_CONST = 295,               /* INT_CONST  */
    UNARY_MINUS = 296              /* UNARY_MINUS  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define LE 258
#define GE 259
#define EQ 260
#define NE 261
#define ADD 262
#define SUB 263
#define MUL 264
#define DIV 265
#define BOOL 266
#define BREAK 267
#define CHAR 268
#define CASE 269
#define CLASS 270
#define CONTINUE 271
#define DECLARE 272
#define DO 273
#define ELSE 274
#define EXIT 275
#define FLOAT 276
#define FOR 277
#define FUN 278
#define IF 279
#define IN 280
#define INT 281
#define LOOP 282
#define PRINT 283
#define PRINTLN 284
#define RANGE 285
#define RETURN 286
#define STRING 287
#define VAL 288
#define VAR 289
#define WHILE 290
#define BOOL_CONST 291
#define REAL_CONST 292
#define STR_CONST 293
#define ID 294
#define INT_CONST 295
#define UNARY_MINUS 296

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 18 "parser.y"

    int i_val;
    string *s_val;
    bool b_val;
    double d_val;
    idInfo* info;
    int type;

#line 158 "y.tab.hpp"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_HPP_INCLUDED  */
