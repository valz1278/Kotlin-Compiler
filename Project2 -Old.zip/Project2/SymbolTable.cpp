#include "SymbolTable.hpp"

SymbolTable::SymbolTable()
{
  index = 0;
}

int SymbolTable::insert(string id, int type, int flag, idValue value, bool init)
{
  if (table_map.find(id) != table_map.end()) {
    return -1;
  }
  else {
    symbols.push_back(id);
    table_map[id].index = index;
    table_map[id].id = id;
    table_map[id].type = type;
    table_map[id].flag = flag;
    table_map[id].value = value;
    table_map[id].init = init;
    return index++;
  }
}

idInfo *SymbolTable::lookup(string id)
{
  if (doesExist(id)) return new idInfo(table_map[id]);
  else return NULL;
}

void SymbolTable::dump()
{
  cout << "<id>\t<flag>\t\t<type>\t<value>" << endl;
  
  for (int i = 0; i < index; ++i)
  {
    string temp;
    idInfo info = table_map[symbols[i]];
    temp = info.id + "\t";

    if(info.flag ==  const_variable_flag) temp += "constant\t";
    else if(info.flag ==  variable_flag) temp += "variable\t";
    else if(info.flag ==  function_flag) temp += "function\t";

    if(info.type ==  int_type) temp += "int\t";
    else if(info.type ==  string_type) temp += "string\t";
    else if(info.type ==  bool_type) temp += "bool\t";
    else if(info.type ==  real_type) temp += "float\t";
    else if(info.type ==  array_type) temp += "array\t";
    else if(info.type ==  void_type) temp += "void\t";

    if (info.init) {
      if(info.type == int_type) temp += to_string(info.value.i_val);
      else if(info.type == real_type) temp += to_string(info.value.d_val);
      else if(info.type == string_type) temp += info.value.s_val;
      else if(info.type == bool_type) temp += (info.value.b_val)? "true" : "false";
    }

    if (info.flag == function_flag) {
      temp += "{ ";
      for (int i = 0; i < info.value.args.size(); ++i) {
        if(info.value.args[i].type == int_type) temp += "int ";
        else if(info.value.args[i].type == real_type) temp += "float ";
        else if(info.value.args[i].type == string_type) temp += "string ";
        else if(info.value.args[i].type == bool_type) temp += "bool ";
      }
      temp += "}";
    }

    if (info.type == array_type) {
      temp += "{ ";
      if(info.value.args[0].type == int_type) temp += "int, ";
      else if(info.value.args[0].type == real_type) temp += "float, ";
      else if(info.value.args[0].type == string_type) temp += "string, ";
      else if(info.value.args[0].type == bool_type) temp += "bool, ";
      temp += to_string(info.value.args.size()) + " }";
    }
    cout << temp << endl;
  }
  cout << endl;
}

bool SymbolTable::doesExist(string id)
{
  return table_map.find(id) != table_map.end();
}

void SymbolTable::setFunType(int type)
{
  table_map[symbols[symbols.size() - 1]].type = type;
}

void SymbolTable::addFunArg(string id, idInfo info)
{
  table_map[symbols[symbols.size() - 1]].value.args.push_back(info);
}

SymbolTableList::SymbolTableList()
{
  top = -1;
  push();
}

void SymbolTableList::push()
{
  list.push_back(SymbolTable());
  ++top;
}

bool SymbolTableList::pop()
{
  if (list.size() <= 0) return false;
  list.pop_back();
  --top;
  return true;
}

int SymbolTableList::insert(string id, idInfo info)
{
  return list[top].insert(id, info.type, info.flag, info.value, info.init);
}

int SymbolTableList::insert(string id, int type, int size)
{
  idValue value;
  value.args = vector<idInfo>(size);
  for(int i = 0; i < size; ++i){
    value.args[i].index = -1;
    value.args[i].type = type;
    value.args[i].flag = variable_flag;
  }
  return list[top].insert(id, array_type, variable_flag, value, false);
}

idInfo *SymbolTableList::lookup(string id)
{
  for (int i = top; i >= 0; --i) {
    if (list[i].doesExist(id)) return list[i].lookup(id);
  }
  return NULL;
}

void SymbolTableList::dump()
{
  cout << endl << "**************************************************" << endl << endl;
  for (int i = top; i >= 0; --i) {
    cout << "Index: " << i << endl;
    list[i].dump();
  }
  cout << "**************************************************" << endl << endl;
}
void SymbolTableList::setFunType(int type)
{
  list[top - 1].setFunType(type);
}

void SymbolTableList::addFunArg(string id, idInfo info)
{
  list[top - 1].addFunArg(id, info);
}

/* utilities */

bool isConstant(idInfo info)
{
  if (info.flag == const_value_flag || info.flag == const_variable_flag) return true;
  else return false;
}

idInfo *intConstant(int value)
{
  idInfo* info = new idInfo();
  info->index = 0;
  info->type = int_type;
  info->value.i_val = value;
  info->flag = const_value_flag;
  return info;
}

idInfo *realConstant(double value)
{
  idInfo* info = new idInfo();
  info->index = 0;
  info->type = real_type;
  info->value.d_val = value;
  info->flag = const_value_flag;
  return info;
}

idInfo *boolConstant(bool value)
{
  idInfo* info = new idInfo();
  info->index = 0;
  info->type = bool_type;
  info->value.b_val = value;
  info->flag = const_value_flag;
  return info;
}

idInfo *strConstant(string *value)
{
  idInfo* info = new idInfo();
  info->index = 0;
  info->type = string_type;
  info->value.s_val = *value;
  info->flag = const_value_flag;
  return info;
}
