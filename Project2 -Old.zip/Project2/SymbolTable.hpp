#include <iostream>
#include <map>
#include <vector>

using namespace std;

enum type{
  int_type,
  real_type,
  bool_type,
  string_type,
  array_type,
  void_type
};

enum idFlag {
  const_value_flag,
  const_variable_flag,
  variable_flag,
  function_flag
};

struct idValue;
struct idInfo;

struct idValue {
  int i_val = 0;
  double d_val = 0;
  bool b_val = false;
  string s_val = "";
  vector<idInfo> args;
};

struct idInfo {
  int index = 0;
  string id = "";
  int type = int_type;
  int flag = variable_flag;
  idValue value;
  bool init = false;
};

class SymbolTable {
  private:
    vector<string> symbols;
    map<string, idInfo> table_map;
    int index;
  public:
    SymbolTable();
    int insert(string id, int type, int flag, idValue value, bool init);
    idInfo *lookup(string id);
    void dump();
    bool doesExist(string id);
    void setFunType(int type);
    void addFunArg(string id, idInfo info);
};

class SymbolTableList {
  private:
    vector<SymbolTable> list;
    int top;
  public:
    SymbolTableList();
    void push();
    bool pop();
    int insert(string id, idInfo info);
    int insert(string id, int type, int size);
    idInfo *lookup(string id);
    void dump();
    void setFunType(int type);
    void addFunArg(string id, idInfo info);
};

bool isConstant(idInfo info);
idInfo *intConstant(int value);
idInfo *realConstant(double value);
idInfo *boolConstant(bool value);
idInfo *strConstant(string *value);
