#include <iostream>
#include <map>
#include <vector>

using namespace std;

enum data_type{
  integer_type,
  real_type,
  bool_type,
  string_type,
  array_type,
  no_type
};

enum identifier_type {
  literal_constant,
  constant_variable,
  variable,
  function
};

struct values;
struct identifierData;

struct values {
  int i_val = 0;
  double d_val = 0;
  bool b_val = false;
  string s_val = "";
  vector<identifierData> arguments;
};

struct identifierData {
  string id = "";
  int data_type = integer_type;
  int id_type = variable;
  values value;
  bool initialized = false;
};

class SymbolTable {
  private:
    vector<string> symbols;
    map<string, identifierData> table_map;
    int index;
  public:
    SymbolTable();
    int insert(string id, int data_type, int identifier_type, values value, bool initialized);
    void dump();
    identifierData* lookup(string id);
    bool doesExist(string id);
    void setReturnType(int type);
    void addArgument(string id, identifierData data);
};