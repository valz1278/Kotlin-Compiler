#include "SymbolTable.hpp"

SymbolTable::SymbolTable()
{
  index = 0;
}

int SymbolTable::insert(string id, int data_type, int identifier_type, values value, bool initialized)
{
  if (doesExist(id)) {
    return -1;
  }
  else {
    symbols.push_back(id);
    table_map[id].id = id;
    table_map[id].data_type = data_type;
    table_map[id].id_type = identifier_type;
    table_map[id].value = value;
    table_map[id].initialized = initialized;
    return index++;
  }
}

identifierData *SymbolTable::lookup(string id)
{
  if (doesExist(id)) return new identifierData(table_map[id]);
  else return NULL;
}

void SymbolTable::dump()
{
  cout << "<id>\t<data_type>\t<id_type>\t<value>" << endl;
  
  for (int i = 0; i < index; ++i)
  {
    string temp;
    identifierData data = table_map[symbols[i]];
    temp = data.id + "\t";

    if(data.data_type ==  integer_type) temp += "int";
    else if(data.data_type ==  string_type) temp += "string";
    else if(data.data_type ==  bool_type) temp += "bool";
    else if(data.data_type ==  real_type) temp += "float";
    else if(data.data_type ==  array_type) temp += "array";
    else if(data.data_type ==  no_type) temp += "void";

    temp += "\t\t";

    if(data.id_type ==  constant_variable) temp += "constant";
    else if(data.id_type ==  variable) temp += "variable";
    else if(data.id_type ==  function) temp += "function";  

    temp += "\t";

    if (data.initialized) {
      if(data.data_type == integer_type) temp += to_string(data.value.i_val);
      else if(data.data_type == real_type) temp += to_string(data.value.d_val);
      else if(data.data_type == string_type) temp += data.value.s_val;
      else if(data.data_type == bool_type) temp += (data.value.b_val)? "true" : "false";
    }

    if (data.id_type == function) {
      temp += "{ ";
      for (int i = 0; i < data.value.arguments.size(); ++i) {
        if(data.value.arguments[i].data_type == integer_type) temp += "int ";
        else if(data.value.arguments[i].data_type == real_type) temp += "float ";
        else if(data.value.arguments[i].data_type == string_type) temp += "string ";
        else if(data.value.arguments[i].data_type == bool_type) temp += "bool ";
      }
      temp += "}";
    }

    if (data.data_type == array_type) {
      temp += "{ ";
      if(data.value.arguments[0].data_type == integer_type) temp += "int, ";
      else if(data.value.arguments[0].data_type == real_type) temp += "float, ";
      else if(data.value.arguments[0].data_type == string_type) temp += "string, ";
      else if(data.value.arguments[0].data_type == bool_type) temp += "bool, ";
      temp += to_string(data.value.arguments.size()) + " }";
    }
    cout << temp << endl;
  }
  cout << endl;
}

bool SymbolTable::doesExist(string id)
{
  return table_map.find(id) != table_map.end();
}

void SymbolTable::setReturnType(int type)
{
  table_map[symbols[symbols.size() - 1]].data_type = type;
}

void SymbolTable::addArgument(string id, identifierData data)
{
  table_map[symbols[symbols.size() - 1]].value.arguments.push_back(data);
}