#include "SymbolTable.hpp"

SymbolTable::SymbolTable()
{
  index = 0;
}

int SymbolTable::insert(string id, int data_type, int identifier_type, values value, bool initialized)
{
  if (doesExist(id)) {
    return -1;
  }
  else {
    symbols.push_back(id);
    table_map[id].id = id;
    table_map[id].data_type = data_type;
    table_map[id].id_type = identifier_type;
    table_map[id].value = value;
    table_map[id].initialized = initialized;
    return index++;
  }
}

identifierData *SymbolTable::lookup(string id)
{
  if (doesExist(id)) return new identifierData(table_map[id]);
  else return NULL;
}

void SymbolTable::dump()
{
  cout << "<id>\t<data_type>\t<id_type>\t<value>" << endl;
  
  for (int i = 0; i < index; ++i)
  {
    string temp;
    identifierData info = table_map[symbols[i]];
    temp = info.id + "\t";

    if(info.data_type ==  integer_type) temp += "int";
    else if(info.data_type ==  string_type) temp += "string";
    else if(info.data_type ==  bool_type) temp += "bool";
    else if(info.data_type ==  real_type) temp += "float";
    else if(info.data_type ==  array_type) temp += "array";
    else if(info.data_type ==  no_type) temp += "void";

    temp += "\t\t";

    if(info.id_type ==  constant_variable) temp += "constant";
    else if(info.id_type ==  variable) temp += "variable";
    else if(info.id_type ==  function) temp += "function";  

    temp += "\t";

    if (info.initialized) {
      if(info.data_type == integer_type) temp += to_string(info.value.i_val);
      else if(info.data_type == real_type) temp += to_string(info.value.d_val);
      else if(info.data_type == string_type) temp += info.value.s_val;
      else if(info.data_type == bool_type) temp += (info.value.b_val)? "true" : "false";
    }

    if (info.id_type == function) {
      temp += "{ ";
      for (int i = 0; i < info.value.arguments.size(); ++i) {
        if(info.value.arguments[i].data_type == integer_type) temp += "int ";
        else if(info.value.arguments[i].data_type == real_type) temp += "float ";
        else if(info.value.arguments[i].data_type == string_type) temp += "string ";
        else if(info.value.arguments[i].data_type == bool_type) temp += "bool ";
      }
      temp += "}";
    }

    if (info.data_type == array_type) {
      temp += "{ ";
      if(info.value.arguments[0].data_type == integer_type) temp += "int, ";
      else if(info.value.arguments[0].data_type == real_type) temp += "float, ";
      else if(info.value.arguments[0].data_type == string_type) temp += "string, ";
      else if(info.value.arguments[0].data_type == bool_type) temp += "bool, ";
      temp += to_string(info.value.arguments.size()) + " }";
    }
    cout << temp << endl;
  }
  cout << endl;
}

bool SymbolTable::doesExist(string id)
{
  return table_map.find(id) != table_map.end();
}

void SymbolTable::setReturnType(int type)
{
  table_map[symbols[symbols.size() - 1]].data_type = type;
}

void SymbolTable::addArgument(string id, identifierData info)
{
  table_map[symbols[symbols.size() - 1]].value.arguments.push_back(info);
}

SymbolTables::SymbolTables()
{
  top = -1;
  push();
}

void SymbolTables::push()
{
  list.push_back(SymbolTable());
  ++top;
}

bool SymbolTables::pop()
{
  if (list.size() <= 0) return false;
  list.pop_back();
  --top;
  return true;
}

int SymbolTables::insert(string id, identifierData info)
{
  return list[top].insert(id, info.data_type, info.id_type, info.value, info.initialized);
}

int SymbolTables::insert(string id, int type, int size)
{
  values value;
  value.arguments = vector<identifierData>(size);
  for(int i = 0; i < size; ++i){
    value.arguments[i].data_type = type;
    value.arguments[i].id_type = variable;
  }
  return list[top].insert(id, array_type, variable, value, false);
}

identifierData *SymbolTables::lookup(string id)
{
  for (int i = top; i >= 0; --i) {
    if (list[i].doesExist(id)) return list[i].lookup(id);
  }
  return NULL;
}

void SymbolTables::dump()
{
  cout << endl << "**************************************************" << endl << endl;
  for (int i = top; i >= 0; --i) {
    cout << "Index: " << i << endl;
    list[i].dump();
  }
  cout << "**************************************************" << endl << endl;
}
void SymbolTables::setReturnType(int type)
{
  list[top - 1].setReturnType(type);
}

void SymbolTables::addArgument(string id, identifierData info)
{
  list[top - 1].addArgument(id, info);
}